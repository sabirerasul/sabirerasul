Element.prototype.rescalendar = function(options) {
    function alert_error(error_message) {
        return [
            '<div class="error_wrapper">',

            '<div class="thumbnail_image vertical-center">',

            "<p>",
            '<span class="error">',
            error_message,
            "</span>",
            "</p>",
            "</div>",

            "</div>",
        ].join("");
    }

    function set_template(targetObj, settings) {
        var template = "",
            id = targetObj.getAttribute("id") || "";

        if (id == "" || settings.dataKeyValues.length == 0) {
            targetObj.innerHTML = alert_error(
                settings.lang.init_error + ": No id or dataKeyValues"
            );
            return false;
        }

        if (settings.refDate.length != 10) {
            targetObj.innerHTML = alert_error(settings.lang.no_ref_date);
            return false;
        }

        template = settings.template_html(targetObj, settings);

        targetObj.innerHTML = template;

        return true;
    }

    function dateInRange(date, startDate, endDate) {
        if (date == startDate || date == endDate) {
            return true;
        }

        var date1 = moment(startDate, settings.format),
            date2 = moment(endDate, settings.format),
            date_compare = moment(date, settings.format);

        return date_compare.isBetween(date1, date2, null, "[]");
    }

    function dataInSet(data, name, date) {
        var obj_data = {};

        for (var i = 0; i < data.length; i++) {
            obj_data = data[i];

            if (
                name == obj_data.name &&
                dateInRange(date, obj_data.startDate, obj_data.endDate)
            ) {
                return obj_data;
            }
        }

        return false;
    }

    function setData(targetObj, dataKeyValues, data) {
        var html = "",
            dataKeyValues = settings.dataKeyValues,
            data = settings.data,
            arr_dates = [],
            name = "",
            content = "",
            hasEventClass = "",
            customClass = "",
            classInSet = false,
            obj_data = {};

        var elemAll = targetObj.querySelectorAll("td.day_cell");
        elemAll.forEach(setelemAll);

        function setelemAll(index, value) {
            arr_dates.push(index.getAttribute("data-cellDate"));
        }

        for (var i = 0; i < dataKeyValues.length; i++) {
            content = "";
            date = "";
            name = dataKeyValues[i];

            html += '<tr class="dataRow">';
            html += '<td class="firstColumn">' + name + "</td>";
            for (var j = 0; j < arr_dates.length; j++) {
                title = "";
                date = arr_dates[j];
                obj_data = dataInSet(data, name, date);

                if (typeof obj_data === "object") {
                    if (obj_data.title) {
                        title = ' title="' + obj_data.title + '" ';
                    }

                    content = '<a href="#" ' + title + ">&nbsp;</a>";
                    hasEventClass = "hasEvent";
                    customClass = obj_data.customClass;
                } else {
                    content = " ";
                    hasEventClass = "";
                    customClass = "";
                }

                //set sunday event class in calendar
                var modifiedDate = date;

                var dsplited = modifiedDate.split("-");

                convertedDate = dsplited[1] + "/" + dsplited[0] + "/" + dsplited[2];

                var leaveDay = new Date(convertedDate);

                var daysNames = [
                    "Sunday",
                    "Monday",
                    "Tuesday",
                    "Wednesday",
                    "Thursday",
                    "Friday",
                    "Saturday",
                ];

                if (daysNames[leaveDay.getDay()] == "Sunday") {
                    leaveCustomClass = "greenClass";
                    customClass = customClass + leaveCustomClass;
                }

                //set blank grey color in empty boxes
                // if (customClass == "") {
                //   leaveCustomClass = "emptyBoxClass";
                //   customClass = customClass + leaveCustomClass;
                // }

                if (customClass != "") {
                    if (customClass == "greenClass") {
                        content =
                            "<div class='circle_box'><div class='circle_50 darkGreen'></div></div>";
                    }

                    if (customClass == "blueClass") {
                        content =
                            "<div class='circle_box'><div class='circle_50 darkBlue'></div></div>";
                    }

                    html +=
                        '<td data-date="' +
                        date +
                        '" data-name="' +
                        name +
                        '" class="data_cell ' +
                        hasEventClass +
                        " " +
                        customClass +
                        '">' +
                        content +
                        "</td>";
                } else {
                    html +=
                        '<td data-date="' +
                        date +
                        '" data-name="' +
                        name +
                        '" class="data_cell ' +
                        hasEventClass +
                        " " +
                        customClass +
                        '">' +
                        content +
                        "</td>";
                }
            }

            html += "</tr>";
        }

        targetObj.querySelector(".rescalendar_data_rows").innerHTML = html;
    }

    function setDayCells(targetObj, refDate) {
        var format = settings.format,
            f_inicio = moment(refDate, format).subtract(settings.jumpSize, "days"),
            f_fin = moment(refDate, format).add(settings.jumpSize, "days"),
            today = moment().startOf("day"),
            html = '<td class="firstColumn"></td>',
            f_aux = "",
            f_aux_format = "",
            dia = "",
            dia_semana = "",
            num_dia_semana = 0,
            mes = "",
            clase_today = "",
            clase_middleDay = "",
            clase_disabled = "",
            middleDay = targetObj.querySelector("input.refDate").value;

        for (var i = 0; i < settings.calSize + 1; i++) {
            clase_disabled = "";

            f_aux = moment(f_inicio).add(i, "days");
            f_aux_format = f_aux.format(format);

            dia = f_aux.format("DD");
            //mes        = f_aux.locale( settings.locale ).format('MMM').replace('.','');
            //dia_semana = f_aux.locale( settings.locale ).format('dd');
            num_dia_semana = f_aux.day();

            f_aux_format == today.format(format) ?
                (clase_today = "today") :
                (clase_today = "");
            f_aux_format == middleDay ?
                (clase_middleDay = "middleDay") :
                (clase_middleDay = "");

            if (
                settings.disabledDays.indexOf(f_aux_format) > -1 ||
                settings.disabledWeekDays.indexOf(num_dia_semana) > -1
            ) {
                clase_disabled = "disabledDay";
            }

            html += [
                '<td class="day_cell ' +
                clase_today +
                " " +
                clase_middleDay +
                " " +
                clase_disabled +
                '" data-cellDate="' +
                f_aux_format +
                '">',
                '<span class="dia_semana">' + dia_semana + "</span>",
                '<span class="dia">' + dia + "</span>",
                '<span class="mes">' + mes + "</span>",
                "</td>",
            ].join("");
        }

        targetObj.querySelector(".rescalendar_day_cells").innerHTML = html;

        addTdClickEvent(targetObj);

        setData(targetObj);
    }

    function addTdClickEvent(targetObj) {
        var day_cell = targetObj.querySelector("td.day_cell");

        day_cell.addEventListener("click", function(e) {
            var cellDate = e.currentTarget.attributes["data-cellDate"].value;

            targetObj.querySelector("input.refDate").value = cellDate;

            setDayCells(targetObj, moment(cellDate, settings.format));
        });
    }



    function change_day(targetObj, action, num_days) {
        var refDate = targetObj.querySelector("input.refDate").value,
            f_ref = "";

        var modifiedDate = refDate;
        var dsplited = modifiedDate.split("-");
        convertedDate = dsplited[2] + "/" + dsplited[1] + "/" + dsplited[0];
        var leaveDay = new Date(convertedDate);

        var month = leaveDay.getMonth() + 1;

        var premonth = leaveDay.getMonth();
        var formonth = leaveDay.getMonth() + 2;
        var year = leaveDay.getFullYear();


        function daysInMonth(month, year) {
            return new Date(year, month, 0).getDate();
        }

        if (action == "subtract") {
            num_days = daysInMonth(premonth, year);
        } else {
            num_days = daysInMonth(month, year);
        }

        console.log(num_days);
        if (action == "subtract") {
            f_ref = moment(refDate, settings.format).subtract(num_days, "days");
        } else {
            f_ref = moment(refDate, settings.format).add(num_days, "days");
        }

        targetObj.querySelector("input.refDate").value = f_ref.format(
            settings.format
        );

        setDayCells(targetObj, f_ref);
    }

    // INITIALIZATION
    //var settings = $.extend(
    var settings = Object.assign({}, {
            id: "rescalendar",
            format: "YYYY-MM-DD",
            refDate: moment().format("YYYY-MM-DD"),
            jumpSize: 15,
            calSize: 30,
            locale: "en",
            disabledDays: [],
            disabledWeekDays: [],
            dataKeyField: "name",
            dataKeyValues: [],
            data: {},

            lang: {
                init_error: "Error when initializing",
                no_data_error: "No data found",
                no_ref_date: "No refDate found",
                today: "Today",
            },

            template_html: function(targetObj, settings) {
                var id = targetObj.getAttribute("id"),
                    refDate = settings.refDate;

                return [
                    '<div class="rescalendar ',
                    id,
                    '_wrapper">',

                    '<div class="rescalendar_controls">',

                    '<button class="move_to_last_month"> << </button>',

                    '<input class="refDate" type="text" value="' + refDate + '" />',

                    '<button class="move_to_next_month"> >> </button>',

                    "<br>",
                    '<button class="move_to_today"> ' +
                    settings.lang.today +
                    " </button>",

                    "</div>",

                    '<table class="rescalendar_table">',
                    "<thead>",
                    '<tr class="rescalendar_day_cells"></tr>',
                    "</thead>",
                    '<tbody class="rescalendar_data_rows">',

                    "</tbody>",
                    "</table>",

                    "</div>",
                ].join("");
            },
        },
        options
    );

    var mycalObj = document.getElementById("my_calendar");
    mycalObj.length = 1;
    const mycalArr = Object.keys(mycalObj);

    return mycalArr.forEach(function() {
        //return $(mycalObj).each(function () {

        let targetObj = mycalObj;

        set_template(targetObj, settings);

        setDayCells(targetObj, settings.refDate);

        // Events
        let move_to_last_month = targetObj.querySelector(".move_to_last_month"),
            move_to_next_month = targetObj.querySelector(".move_to_next_month"),
            move_to_today = targetObj.querySelector(".move_to_today"),
            refDate = targetObj.querySelector(".refDate");

        move_to_last_month.addEventListener("click", function(e) {
            change_day(targetObj, "subtract", 30);
        });


        move_to_next_month.addEventListener("click", function(e) {
            change_day(targetObj, "add", 30);
        });

        refDate.addEventListener("blur", function(e) {
            let refDate = targetObj.querySelector("input.refDate").value;
            setDayCells(targetObj, refDate);
        });

        move_to_today.addEventListener("click", function(e) {
            let today = moment().startOf("day").format(settings.format);
            targetObj.querySelector("input.refDate").value = today;

            setDayCells(targetObj, today);
        });

        return this;
    });
}; // end rescalendar plugin

function padTo2Digits(num) {
    return num.toString().padStart(2, "0");
}

function formatDate(date) {

    var day = date.getDate();
    var month = date.getMonth() + 1;
    var year = date.getFullYear();

    var oldDate = year + "-" + month + "-" + 1;
    date = new Date(oldDate);

    return [
        padTo2Digits(date.getDate()),
        padTo2Digits(date.getMonth() + 1),
        date.getFullYear(),
    ].join("-");
}